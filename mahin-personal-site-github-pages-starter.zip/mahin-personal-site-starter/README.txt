MAHIN AZAM — PERSONAL WEBSITE
============================
GitHub account: mahinazam
Repository: mahin-personal-site
Planned custom domain: mahinazam.com

UPLOAD THESE FOUR FILES NOW
---------------------------
- index.html
- robots.txt
- sitemap.xml
- README.txt

Upload these four files directly into the repository ROOT (not inside a
subfolder). Keep the repository public.

Do NOT add a CNAME file or set the custom domain yet unless you have already
registered and control mahinazam.com. After the domain is registered, set the
custom domain in repository Settings > Pages. GitHub can create/update the
CNAME file when you save the custom domain there.

ENABLE GITHUB PAGES
-------------------
1. Open repository Settings > Pages.
2. Under Build and deployment, select Deploy from a branch.
3. Choose branch main and folder /(root), then Save.
4. Wait for the deployment to finish. Your temporary website should be:
   https://mahinazam.github.io/mahin-personal-site/

CUSTOM DOMAIN — LATER
--------------------
After registering mahinazam.com, set it as the Custom domain in Settings >
Pages and follow GitHub's current DNS instructions. GitHub's documented apex
A records are:
185.199.108.153
185.199.109.153
185.199.110.153
185.199.111.153

For www, use a CNAME to mahinazam.github.io. Check GitHub's documentation and
your registrar's interface before changing DNS. Do not delete email-related
MX/TXT records. Enable Enforce HTTPS once GitHub makes it available.

GOOGLE SEARCH CONSOLE — AFTER THE DOMAIN WORKS
----------------------------------------------
1. Add mahinazam.com as a Domain property in Google Search Console.
2. Verify using the exact DNS TXT record Google provides.
3. Submit https://mahinazam.com/sitemap.xml.
4. Use URL Inspection to request indexing of https://mahinazam.com/.

Threads is omitted until the exact profile URL is supplied. The site includes
only the social profile URLs provided so far. Do not add private contact or
location details merely to improve search visibility.
